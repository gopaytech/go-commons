## [0.0.5](https://source.golabs.io/cloud-platform/automation/poc/scp-template-gcp-postgressql/compare/v0.0.4...v0.0.5) (2021-07-27)


### Bug Fixes

* delimiter for terraform changed from {{ }} to [[ ]], remove *.tmpl... ([fd5d869](https://source.golabs.io/cloud-platform/automation/poc/scp-template-gcp-postgressql/commit/fd5d869ed8008ccb4f0a0baf18ffb5c4ffe8d5a5))

## [0.0.4](https://source.golabs.io/cloud-platform/automation/poc/scp-template-gcp-postgressql/compare/v0.0.3...v0.0.4) (2021-07-27)


### Bug Fixes

* delimiter for terraform changed from {{ }} to [[ ]] ([7fd042a](https://source.golabs.io/cloud-platform/automation/poc/scp-template-gcp-postgressql/commit/7fd042a3f228a3763011061a84bca7cdfe72174d))
